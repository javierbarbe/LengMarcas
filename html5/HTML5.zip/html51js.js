var letras="abcdefghijklmnñopqrstuvwxyzAQWERTYUIOPSDFGHJKLÑZXCVBNM";
var arroba="@";
function compruebaTo(){
	compruebaMail();
    var nomComp=1;
    var nombre= document.getElementById('nombre').value;
    if (nombre.length>0){
         for (i=0;i<nombre.length;i++){
		 	var carPos=nombre.charAt(i);
			if(letras.indexOf(carPos)==-1){
				alert('Solo admite letras');
				nomComp=0;
				document.getElementById('nombre').focus();
				document.getElementById('nombre').value="";
				
				break;
			}//else cierra
		 }//for cierra
    } //if cierra
	else{
        alert('por favor Nombre no puede quedar vacio');
        document.getElementById('nombre').focus();
		nomComp=0;
    }
    var ape1Comp=1;
    var ape1= document.getElementById('apellido1').value;
    if(ape1.length>0){
		  for (i=0;i<ape1.length;i++){
		 	var carPos=ape1.charAt(i);
			if(letras.indexOf(carPos)==-1){
				alert('Solo admite letras');
				ape1Comp=0;
				document.getElementById('apellido1').focus();
				document.getElementById('apellido1').value="";
				
			}//if cierrra
		 } // for cierra
        
    }else{
        alert('por favor Apellido1 no puede quedar vacio');
        ape1Comp=0;
    }
    var ape2Comp=1;
    var ape2= document.getElementById('apellido2').value;
    if(ape2.length>0){
		for (i=0;i<ape2.length;i++){
		 	var carPos=ape2.charAt(i);
			if(letras.indexOf(carPos)==-1){				 
				alert('Solo admite letras');
				ape2Comp=0;
				document.getElementById('apellido2').focus();
				document.getElementById('apellido2').value="";
				
			}//if cierra
	   } //for cierra
       
    }else{
        alert('por favor Apellido2 no puede quedar vacio');
		ape2Comp=0;
    }
    if (nomComp!=0){
        alert('nombre relleno');
		document.getElementById('nombre').style.backgroundColor="white";
        if(ape1Comp!=0){
            alert('apellido1 relleno');
			document.getElementById('apellido1').style.backgroundColor="white";
            if(ape2Comp!=0){
                alert('apellido2 relleno');
				document.getElementById('apellido2').style.backgroundColor="white";
                document.getElementById('areaComentario').value="Datos introducidos correctamente";
            } else{
                document.getElementById('areaComentario').value="Datos introducidos INCORRECTOS";
                document.getElementById('apellido2').style.backgroundColor="red";
				document.getElementById('apellido2').focus();
            }
        }else{
            document.getElementById('areaComentario').value="Datos introducidos INCORRECTOS";
            document.getElementById('apellido1').style.backgroundColor="red";
			document.getElementById('apellido1').focus();
        }
    }else{
        document.getElementById('areaComentario').value="Datos introducidos INCORRECTOS";
         document.getElementById('nombre').style.backgroundColor="red";
		 document.getElementById('nombre').focus();
    }
    if(nomComp!=0 && ape1Comp!=0 && ape2Comp!=0){
            alert('Tras comprobar todo y ser correcto, el formulario NO  se envia');
}else{
    alert('rellena');
}

  
}// fin compruebaTo()

function pon_submenu(){
       
   
    var carnetSi=document.getElementById('carnetSi').checked;
    
    if (carnetSi==true){
            document.getElementById('cochePropio').style.display = "inline";
           
    } else{
        document.getElementById('cochePropio').style.display = "none";
        document.getElementById('menuColor').style.display = "none";
        document.getElementById('marcaCoche').style.display= " none";
        document.getElementById('cocheNo').checked=true;
       
        
    }

   
    
} // fin pon_submenu

function submenu2(){
    var cocheSi=document.getElementById('cocheSi').checked;
    if( cocheSi==true){
        document.getElementById('menuColor').style.display = "inline";
        document.getElementById('marcaCoche').style.display= "inline";
    }else{
        document.getElementById('menuColor').style.display = "none";
        document.getElementById('marcaCoche').style.display= "none";
        document.getElementById('selecMarca').selectedIndex=0;
        document.getElementById('autoCol').value="#000000";
        // document.getElementById('autoCol').
    }
}// fin submenu2

function contrasenias(){
    var contraComp=0;
    var contra= document.getElementById('pass1').value;
    var contra2=document.getElementById('pass2').value;
    if(contra.length>0){
        contraComp=1;
    }else{
        alert('por favor Contraseña no puede quedar vacio');
    }
   
    if(contra2!=contra){
        alert('Las contraseñas no coinciden');
        contraComp=0;
        document.getElementById('pass2').focus();
    }
}
function compruebaMail(){
	var emailComp=1;
	alert('correo');
	var correos=document.getElementById('correo').value;
	var posArroba=correos.indexOf(arroba);
	alert (posArroba);
}