var letras="abcdefghijklmnñopqrstuvwxyzAQWERTYUIOPSDFGHJKLÑZXCVBNM";
var arroba="@";
window.onload=function(){
    this.document.getElementById("formulario").onsubmit=d;
}
function compruebaTo(){
    var nomComp=compruebaNombre();
    var ape1Comp=compruebaApellido1();
    var ape2Comp=compruebaApellido2()
    var emailComp=compruebaMail();
   
 //  alert(emailComp);
    if (nomComp!=0){
       // alert('nombre relleno');
		document.getElementById('nombre').style.backgroundColor="white";
        if(ape1Comp!=0){
           // alert('apellido1 relleno');
			document.getElementById('apellido1').style.backgroundColor="white";
            if(ape2Comp!=0){
              //  alert('apellido2 relleno');
                document.getElementById('apellido2').style.backgroundColor="white";
                if(emailComp!=0){
                    document.getElementById('areaComentario').value="Datos introducidos correctamente";
                }else{
                    document.getElementById('areaComentario').value="Datos introducidos INCORRECTOS";
                    document.getElementById('correo').focus();
                }
                
            } else{
                document.getElementById('areaComentario').value="Datos introducidos INCORRECTOS";
                document.getElementById('apellido2').style.backgroundColor="red";
				document.getElementById('apellido2').focus();
            }
        }else{
            document.getElementById('areaComentario').value="Datos introducidos INCORRECTOS";
            document.getElementById('apellido1').style.backgroundColor="red";
			document.getElementById('apellido1').focus();
        }
    }else{
        document.getElementById('areaComentario').value="Datos introducidos INCORRECTOS";
         document.getElementById('nombre').style.backgroundColor="red";
		 document.getElementById('nombre').focus();
    }
    if(nomComp!=0 && ape1Comp!=0 && ape2Comp!=0 && emailComp!=0){
            alert('Tras comprobar todo y ser correcto, el formulario NO  se envia');
            
}else{
    alert('Completa los campos requeridos');
}

  
}// fin compruebaTo()

function pon_submenu(){
       
   
    var carnetSi=document.getElementById('carnetSi').checked;
    
    if (carnetSi==true){
            document.getElementById('cochePropio').style.display = "inline";
           
    } else{
        document.getElementById('cochePropio').style.display = "none";
        document.getElementById('menuColor').style.display = "none";
        document.getElementById('marcaCoche').style.display= " none";
        document.getElementById('cocheNo').checked=true;
       
        
    }

   
    
} // fin pon_submenu

function submenu2(){
    var cocheSi=document.getElementById('cocheSi').checked;
    if( cocheSi==true){
        document.getElementById('menuColor').style.display = "inline";
        document.getElementById('marcaCoche').style.display= "inline";
    }else{
        document.getElementById('menuColor').style.display = "none";
        document.getElementById('marcaCoche').style.display= "none";
        document.getElementById('selecMarca').selectedIndex=0;
        document.getElementById('autoCol').value="#000000";
        // document.getElementById('autoCol').
    }
}// fin submenu2

function contrasenias(){
    var contraComp=0;
    var contra= document.getElementById('pass1').value;
    var contra2=document.getElementById('pass2').value;
    if(contra.length>0){
        contraComp=1;
    }else{
        alert('por favor Contraseña no puede quedar vacio');
    }
   
    if(contra2!=contra){
        alert('Las contraseñas no coinciden');
        contraComp=0;
        document.getElementById('pass2').focus();
        document.getElementById('pass2').value="";
        
    }
    //compruebaTo();
    
}
function compruebaMail(){
	var emailComp=1;
	//alert('correo');
	var correos=document.getElementById('correo').value;
    var posArroba=correos.indexOf("@");
    if(correos.length<1){
        document.getElementById('correo').style.border="orange 2px solid";
        emailComp=0;
    }else{
    if(posArroba==-1){
        document.getElementById('correo').focus();
        emailComp=0;
        document.getElementById('correo').style.border="orange 2px solid";
       // alert(emailComp);
    }
   // alert ('esta es la posicion de la arroba '+posArroba);
    var posArroba2=correos.substring(posArroba+1);
    //alert(posArroba2 +'esto es posArroba2');
    if(posArroba2.indexOf("@")>=0){
        alert('solo una @ ');//+ posArroba2.indexOf("@"));
        emailComp=0;
        document.getElementById('correo').style.border="orange 2px solid";
    }
  //  alert(posArroba);
    if(posArroba2.indexOf(".com")==-1 && posArroba2.indexOf(".es")==-1){
        alert('no hay terminacion .com o .es');
        document.getElementById('correo').style.border="orange 2px solid";
        emailComp=0;
    }
   
    var hastaPuntoCom=posArroba2.substring(0, posArroba2.indexOf(".com"));
    var medidaPuntoCom=hastaPuntoCom.length;
    var hastaPuntoes=posArroba2.substring(0, posArroba2.indexOf(".es"));
   var medidaPuntoEs=hastaPuntoes.length;
    alert(medidaPuntoCom);
    alert(medidaPuntoEs+' es la medida hasta .es');
    alert (hastaPuntoCom +' esto es hasta el puntoCOm');
   if(hastaPuntoCom.length!=0 || hastaPuntoes.length!=0){
    emailComp=1;
   }else{
      emailComp=0;
   }
   
  
    
  
} if(emailComp!=0){
    document.getElementById('correo').style.border="none";
}else{
    document.getElementById('correo').style.border="orange 2px solid";
}
    alert(emailComp+' valor de emailComp');
    return emailComp;
}

function compruebaNombre(){
    var nomComp=1;
    var nombre= document.getElementById('nombre').value;
    if (nombre.length>0){
         for (i=0;i<nombre.length;i++){
		 	var carPos=nombre.charAt(i);
			if(letras.indexOf(carPos)==-1){
				alert('Solo admite letras');
				nomComp=0;
				document.getElementById('nombre').focus();
				document.getElementById('nombre').value="";
				document.getElementById('nombre').style.backgroundColor="red";
				break;
			}//else cierra
		 }//for cierra
    } //if cierra
	else{
       // alert('por favor Nombre no puede quedar vacio');
        document.getElementById('nombre').focus();
		nomComp=0;
    }
    return nomComp;
}

function compruebaApellido1(){
    var ape1Comp=1;
    var ape1= document.getElementById('apellido1').value;
    if(ape1.length>0){
		  for (i=0;i<ape1.length;i++){
		 	var carPos=ape1.charAt(i);
			if(letras.indexOf(carPos)==-1){
				alert('Solo admite letras');
				ape1Comp=0;
				document.getElementById('apellido1').focus();
				document.getElementById('apellido1').value="";
				
			}//if cierrra
		 } // for cierra
        
    }else{
       // alert('por favor Apellido1 no puede quedar vacio');
        document.getElementById('apellido1').focus();
        document.getElementById('apellido1').style.backgroundColor="red";
        ape1Comp=0;
    }
    return ape1Comp;
}

function compruebaApellido2(){
    var ape2Comp=1;
    var ape2= document.getElementById('apellido2').value;
    if(ape2.length>0){
		for (i=0;i<ape2.length;i++){
		 	var carPos=ape2.charAt(i);
			if(letras.indexOf(carPos)==-1){				 
				alert('Solo admite letras');
				ape2Comp=0;
				document.getElementById('apellido2').focus();
				document.getElementById('apellido2').value="";
				
			}//if cierra
	   } //for cierra
       document.getElementById('apellido2').style.backgroundColor="white";  
    }else{
        //alert('por favor Apellido2 no puede quedar vacio');
        document.getElementById('apellido2').focus();
        document.getElementById('apellido2').style.backgroundColor="red";
		ape2Comp=0;
    }
    return ape2Comp;
}