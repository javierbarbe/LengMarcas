function barra(){

    var nom=document.getElementById('nomb').value;
    var ape=document.getElementById('apellido').value;
    var dni=document.getElementById('dni').value;
    var mail=document.getElementById('email').value;
   
   
    if(nom.length>0 || ape.length>0 ||dni.length>0 || mail.length>0){
        document.getElementById('barra').value=25;
    }else{
        barra=0;
    }
    if(nom.length>0 && ape.length>0){
        document.getElementById('barra').value=50;
    }
    if(nom.length>0 &&dni.length>0 ){
        document.getElementById('barra').value=50;
    }
    if(nom.length>0 &&mail.length>0){
        document.getElementById('barra').value=50;
    }
    if(ape.length>0 &&dni.length>0 ){
        document.getElementById('barra').value=50;
    }
    if( ape.length>0&& mail.length>0){
        document.getElementById('barra').value=50;
    }
    if(dni.length>0 && mail.length>0){
        document.getElementById('barra').value=50;
    }
    if(nom.length>0 && ape.length>0 &&dni.length>0 ){
        document.getElementById('barra').value=75;
    }
    if( ape.length>0 &&dni.length>0 && mail.length>0){
        document.getElementById('barra').value=75;
    }
    if(dni.length>0 && mail.length>0 && nom.length>0 ){
        document.getElementById('barra').value=75;
    }
    if(nom.length>0 && ape.length>0 && dni.length>0 && mail.length>0){
        document.getElementById('barra').value=100;
    }
    habilita();
}

function habilita(){
    var barra=document.getElementById('barra').value;
    if(barra==100){
        document.getElementById('envio').disabled=false;
    }else{
        document.getElementById('envio').disabled=true;
    }
}